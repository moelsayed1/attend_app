import 'package:flutter/material.dart';

class AppColor {
  static Color textColor = const Color(0xff5e7389);
  static Color primaryColor = const Color(0xff6fd943);
  static Color themeGreenColor = const Color(0xff6fd943);
  static Color darkGreenColor = const Color(0xFF013D29);
  static Color unSelectedGreyColor = const Color(0xffC9C9C9);
  static Color itemTextColor = const Color(0xFF360E0E);
  static Color redColor = const Color(0xFFFF5B5B);
  static Color appBackgroundColor = const Color(0xFFFAF9F9);
  static Color shadowColor = const Color(0xFF360E0E);
  static Color cBackGround = Color(0xffFFFFFF);
  static Color cText = Color(0xff1E222B);
  static Color cRed = Color(0xffFC275A);

  static Color dividerColor = Color(0xffD9D9D9);
  static Color cDivider = Color(0xffDCE2ED);
  static Color cLabel = Color(0xff000000);
  static Color darkGray = Color(0xFFBABABA);
  static Color cBorder = Color(0xff5E7389);
  static Color cDarkGreyFont = Color(0xff5E7389);
  static Color appBackGround = Color(0xFFF3F3F3);
  static Color darkGreen = Color(0xFF013D29);
  static Color cWhite = Color(0xFFFFFFFF);
  static Color cBlack = Color(0xFF000000);
  static Color grey = Color(0xff777777);

  static Color cWhiteFont = Color(0xffFAFBFD);
  static Color cBlackFont = Colors.black;
  static Color cFont = Color(0xff172C4E);
  static Color cLightGrey = Color(0xffB2BBCE);
  static Color cGreenFont = Color(0xff6FD943);
  static Color cGrey = Color(0xffF1F6FB);


  static Color cRedText = Color(0xffFC5E71);
  static Color cHintFont = Color(0xffFFFFFF);
  static Color pending = Color(0xffFFD700);
  static Color approved = Color(0xff00FF00);
  static Color reject = Color(0xffFF0000);



  static Color cShadow = Color.fromRGBO(0, 0, 0, 0.04);

}
