import 'package:attendance/utils/app_color.dart';
import 'package:attendance/utils/app_constant.dart';
import 'package:attendance/utils/prefer.dart';
import 'package:attendance/views/pages/dashboard_screen.dart';
import 'package:attendance/views/pages/home%20_screen.dart';
import 'package:attendance/views/pages/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get_storage/get_storage.dart';
import 'package:logger/logger.dart';

GetStorage? getStorage;
var logger = Logger();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  getStorage = GetStorage();
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    String languageCode = Prefs.getString(AppConstant.LANGUAGE_CODE) == ''
        ? 'en'
        : Prefs.getString(AppConstant.LANGUAGE_CODE);
    String countryCode =
        Prefs.getString(AppConstant.LANGUAGE_CODE) == 'ar' ? 'AR' : 'US';
    Locale locale = Locale(languageCode, countryCode);

    getToken() async {
      await dotenv.load(fileName: "asset/.env");
      String isDemoMode = dotenv.get(AppConstant.isDemoMode);
      Prefs.setBool(AppConstant.isDemoMode, bool.parse(isDemoMode));
      String accessToken = Prefs.getToken();
      return accessToken;
    }

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Attendance',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primaryColor),
          fontFamily: "Outfit",
          useMaterial3: true,
          dialogBackgroundColor: AppColor.cWhite,
          dialogTheme: DialogTheme(backgroundColor: AppColor.cWhite)),
      home: FutureBuilder(
        future: getToken(),
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.hasData && snapshot.data != '') {
            return DashboardScreen();
          } else {
            return LoginScreen();
          }
        },
      ),
    );
  }
}
